package com.kb;

public class testCertCreation extends KBCertCreator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String log = createCertContainer();
		
		System.out.println(log);

	}

}
