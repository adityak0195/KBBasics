package com.kb;

import jcifs.smb.SmbFile;

public class testFastemsConnection extends KBFastemsThingShape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}
}
